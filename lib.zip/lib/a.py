from os import system ,path
import shutil
import datetime

while True:
    if (datetime.datetime.now >datetime.datetime.Parse("23:00")):
        system("./upload.sh")
    result=system("./getMotion.py")
    if (result==True):
        image=captureImage()
        carNum=system("tesseract a.jpg")
        image.write(carNum+datetime.datetime.now+".jpg")

