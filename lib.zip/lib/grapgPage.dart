import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:incidentresponse/pieChartWidget.dart';

class GraphPage extends StatefulWidget {
  @override
  _GraphPageState createState() => _GraphPageState();
}

class _GraphPageState extends State<GraphPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Text(
            "Needs",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Barchart(),
          SizedBox(
            height: 30,
          ),
          Container(
            child: PieChartSample3(data: {
              "Adults": {"color": Color(0xff0293ee), "data": 50},
              "Children": {"color": Color(0xfff8b250), "data": 30},
              "Elderly": {"color": Color(0xff845bef), "data": 20}
            }),
          ),
          Text(
            "Current Emergency",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Container(
            child: PieChartSample3(data: {
              "Emergency": {"color": Colors.red, "data": 80},
              "ok": {"color": Color(0xfff8b250), "data": 20},
              // "Elderly": {"color": Color(0xff845bef), "data": 20}
            }),
          )
        ],
      ),
    );
  }
}

class Barchart extends StatefulWidget {
  @override
  _BarchartState createState() => _BarchartState();
}

class _BarchartState extends State<Barchart> {
  final Color barBackgroundColor = const Color(0xff72d8bf);
  final Duration animDuration = const Duration(milliseconds: 250);

  int touchedIndex = -1;

  bool isPlaying = false;

  BarChartData mainBarData() {
    return BarChartData(
      barTouchData: BarTouchData(
        touchTooltipData: BarTouchTooltipData(
            tooltipBgColor: Colors.blueGrey,
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              String weekDay;
              switch (group.x.toInt()) {
                case 0:
                  weekDay = 'Transportation';
                  break;
                case 1:
                  weekDay = 'Water';
                  break;
                case 2:
                  weekDay = 'Food';
                  break;

                case 3:
                  weekDay = 'Structural\nInspection';
                  break;
                case 4:
                  weekDay = 'First Aid';
                  break;
                case 5:
                  weekDay = 'Shelter';
                  break;
                default:
                  throw Error();
              }
              return BarTooltipItem(
                weekDay + '\n',
                TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
                children: <TextSpan>[
                  TextSpan(
                    text: (rod.y - 1).toString(),
                    style: TextStyle(
                      color: Colors.yellow,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              );
            }),
        touchCallback: (barTouchResponse) {
          setState(() {
            if (barTouchResponse.spot != null &&
                barTouchResponse.touchInput is! PointerUpEvent &&
                barTouchResponse.touchInput is! PointerExitEvent) {
              touchedIndex = barTouchResponse.spot.touchedBarGroupIndex;
            } else {
              touchedIndex = -1;
            }
          });
        },
      ),
      titlesData: FlTitlesData(
        show: true,
        bottomTitles: SideTitles(
          showTitles: true,
          getTextStyles: (value) => const TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
          margin: 16,
          rotateAngle: 270,
          getTitles: (double value) {
            switch (value.toInt()) {
              case 0:
                return 'Transportation';
              case 1:
                return 'Water';
              case 2:
                return 'Food';
              case 3:
                return 'First Aid';
              case 4:
                return 'Structural\nInspection';
              case 5:
                return 'Shelter';
              default:
                return '';
            }
          },
        ),
        leftTitles: SideTitles(
          showTitles: false,
        ),
      ),
      borderData: FlBorderData(
        show: false,
      ),
      barGroups: showingGroups(),
    );
  }

  List<BarChartGroupData> showingGroups() => List.generate(6, (i) {
        switch (i) {
          case 0:
            return makeGroupData(0, 5, isTouched: i == touchedIndex);
          case 1:
            return makeGroupData(1, 6, isTouched: i == touchedIndex);
          case 2:
            return makeGroupData(2, 5, isTouched: i == touchedIndex);
          case 3:
            return makeGroupData(3, 7, isTouched: i == touchedIndex);
          case 4:
            return makeGroupData(4, 9, isTouched: i == touchedIndex);
          case 5:
            return makeGroupData(5, 11, isTouched: i == touchedIndex);
          // case 6:
          //   return makeGroupData(6, 6.5, isTouched: i == touchedIndex);
          default:
            return throw Error();
        }
      });
  BarChartGroupData makeGroupData(
    int x,
    double y, {
    bool isTouched = false,
    Color barColor = Colors.white,
    double width = 35,
    List<int> showTooltips = const [],
  }) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          y: isTouched ? y + 1 : y,
          colors: isTouched ? [Colors.yellow] : [barColor],
          width: width,
          backDrawRodData: BackgroundBarChartRodData(
            show: true,
            y: 20,
            colors: [barBackgroundColor],
          ),
        ),
      ],
      showingTooltipIndicators: showTooltips,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        width: 250,
        height: 250,
        child: BarChart(
          mainBarData(),
          swapAnimationDuration: Duration(milliseconds: 150), // Optional
          swapAnimationCurve: Curves.linear, // Optional
        ),
      ),
    );
  }
}
