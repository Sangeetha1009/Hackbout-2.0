import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:incidentresponse/grapgPage.dart';
import 'package:incidentresponse/tablepage.dart';
import 'constants.dart';
import 'maps.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Incident Response',
      theme: ThemeData.dark(),
      // ThemeData(
      //   primarySwatch: Colors.blue,
      // ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int pageNum = 0;
  Future<void> loadData() async {
    String data = await rootBundle.loadString("asset/data.txt");
    kdata1 = data.split("\n");
  }

  @override
  void initState() {
    super.initState();
    loadData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Incident Response System using LoRa"),
      ),
      bottomNavigationBar: Container(
        child: BottomNavigationBar(
          onTap: (val) {
            setState(() {
              pageNum = val;
            });
          },
          currentIndex: pageNum,
          items: [
            BottomNavigationBarItem(
              icon: new Icon(Icons.location_on),
              label: 'Map',
            ),
            BottomNavigationBarItem(
              icon: new Icon(Icons.poll_outlined),
              label: 'Graphs',
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.table_view), label: 'Data'),
          ],
        ),
      ),
      body: [MapPage(), GraphPage(), TablePage()][pageNum],
    );
  }
}

class MapPage extends StatefulWidget {
  @override
  _MapPageState createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Maps(),
    );
  }
}
