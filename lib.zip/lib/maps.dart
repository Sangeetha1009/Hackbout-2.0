import 'package:flutter/material.dart';
import 'package:mapbox_gl/mapbox_gl.dart';
import 'dart:async';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_progress_hud/flutter_progress_hud.dart';

const String ACCESS_TOKEN =
    "pk.eyJ1Ijoic3VtdWtoMTIzIiwiYSI6ImNrcGtwN2RpcTF4cHYycHJpb2R2OHJ4dGoifQ.KqHcxrHCmQLIUkiIgItoTQ";

class Maps extends StatefulWidget {
  @override
  _MapsState createState() => _MapsState();
}

class _MapsState extends State<Maps> {
  static final LatLng center = const LatLng(14.168261, 75.035334);

  // final databaseReference = FirebaseDatabase.instance.reference();
  List sensorData = [];
  MapboxMapController controller;
  Circle _selectedCircle;
  bool dataLoaded = false;

  @override
  void initState() {
    super.initState();
    // load();
    getData();
  }

  void _onMapCreated(MapboxMapController controller) {
    this.controller = controller;
    controller.onCircleTapped.add(_onCircleTapped);
    Future.delayed(const Duration(milliseconds: 500), () {
      _add();
      setState(() {});
    });
    print("added");
  }

  @override
  void dispose() {
    controller?.onCircleTapped?.remove(_onCircleTapped);
    super.dispose();
  }

  void _onCircleTapped(Circle circle) async {
    if (_selectedCircle != null) {
      // _updateSelectedCircle(
      //   const CircleOptions(circleRadius: 60),
      // );
    }
    setState(() {
      _selectedCircle = circle;
    });
    LatLng latLng = (await controller.getCircleLatLng(circle));
    print(circle.data);

    Scaffold.of(context).showSnackBar(
      SnackBar(
        content: Text(
            "Latitude - ${latLng.latitude}  \nLongitude - ${latLng.longitude}"),
      ),
    );
  }

  // void _updateSelectedCircle(CircleOptions changes) {
  //   controller.updateCircle(_selectedCircle, changes);
  // }

  Future<void> getData() async {
    String data = await rootBundle.loadString("asset/data.txt");
    List data1 = data.split("\n");

    for (var d in data1) {
      sensorData.add(d.split('*'));
    }
    print(sensorData.last);
  }

  void _add() {
    for (var dat in sensorData) {
      controller.addCircle(
          CircleOptions(
              circleStrokeWidth: 1,
              circleRadius: 5,
              circleOpacity: 0.4,
              geometry: LatLng(double.parse(dat[13]), double.parse(dat[14])),
              circleColor: "#FF0000"),
          {"data": dat});
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ProgressHUD(
        child: Builder(
          builder: (context) => Center(
            child: SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: MapboxMap(
                myLocationTrackingMode: MyLocationTrackingMode.TrackingGPS,
                accessToken: ACCESS_TOKEN,
                onMapCreated: _onMapCreated,
                initialCameraPosition: const CameraPosition(
                    target: LatLng(14.168261, 75.035334), zoom: 14.0),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
