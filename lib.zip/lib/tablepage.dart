import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'constants.dart';

class TablePage extends StatefulWidget {
  @override
  _TablePageState createState() => _TablePageState();
}

class _TablePageState extends State<TablePage> {
  List<DataRow> sensorData = [];

  Future<List> getData(dynamic firestoreData) async {
    print("in get data");
    print(firestoreData);
    // String data = await rootBundle.loadString("asset/data.txt");
    // List data1 = data.split("\n");
    int count = 0;

    for (var line in kdata1) {
      List<DataCell> temp = [];
      count += 1;
      temp.add(DataCell(Text(count.toString())));
      for (var fieldData in line.split('*')) {
        temp.add(
          DataCell(Text(fieldData)),
        );
      }
      print(temp.length);
      sensorData.add(DataRow(cells: temp));
      // setState(() {});
    }
    for (var i in firestoreData) {
      List<DataCell> temp = [];
      count += 1;
      temp.add(DataCell(Text(count.toString())));
      List datafields = (i.data()['data'].split('*'));
      for (var field in datafields.getRange(0, datafields.length - 1)) {
        temp.add(
          DataCell(Text(field)),
        );
      }
      temp.add(
        DataCell(Text("lat")),
      );
      temp.add(
        DataCell(Text("lon")),
      );
      print(temp.length);
      sensorData.add(DataRow(cells: temp));
    }
    return sensorData;

    // print(sensorData.last);
  }

// Sumukh*Yr*Sorab road*Sagar*577401*9148939841*sos*water*2*5*5*Yes*I am in emergency*
  @override
  void initState() {
    super.initState();
    // getData();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scrollbar(
        child: ListView(
          children: [
            StreamBuilder(
              stream:
                  FirebaseFirestore.instance.collection("response").snapshots(),
              builder: (BuildContext context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                } else {
                  try {
                    print(snapshot.data.docs[0].data());
                  } catch (e) {
                    print(e);
                  }

                  return FutureBuilder(
                      future: getData(snapshot.data.docs),
                      builder: (context, snapshot1) {
                        if (snapshot1.connectionState ==
                            ConnectionState.waiting) {
                          return CircularProgressIndicator();
                        }
                        // getData(snapshot.data.docs);
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(columns: [
                            DataColumn(label: Text('Sl.no')),
                            DataColumn(label: Text('First Name')),
                            DataColumn(label: Text('Last Name')),
                            DataColumn(label: Text('Address')),
                            DataColumn(label: Text('City')),
                            DataColumn(label: Text('Zipcode')),
                            DataColumn(label: Text('Phone No.')),
                            DataColumn(label: Text('Current Status')),
                            DataColumn(label: Text('Needs')),
                            DataColumn(label: Text('Adults')),
                            DataColumn(label: Text('Children')),
                            DataColumn(label: Text('Elderly')),
                            DataColumn(label: Text('Pets')),
                            DataColumn(label: Text('Comments')),
                            DataColumn(label: Text('Latitude')),
                            DataColumn(label: Text('Longitude')),
                          ], rows: snapshot1.data),
                        );
                      });
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
